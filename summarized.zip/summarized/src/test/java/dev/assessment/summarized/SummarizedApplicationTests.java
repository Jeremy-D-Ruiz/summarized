package dev.assessment.summarized;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SummarizedApplicationTests {

	@Test
	void contextLoads() {
	}

}
