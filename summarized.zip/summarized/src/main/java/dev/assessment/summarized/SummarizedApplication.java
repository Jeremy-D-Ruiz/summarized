package dev.assessment.summarized;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SummarizedApplication {

	public static void main(String[] args) {
		SpringApplication.run(SummarizedApplication.class, args);
	}

}
